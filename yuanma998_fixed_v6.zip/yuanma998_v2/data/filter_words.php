<?php exit;?>
[
    "草你"
]