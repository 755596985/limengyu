<?php
$file = '/www/wwwroot/mnbt.205620724c/couple_site/admin/manage.php';
exec("php -l $file 2>&1", $out, $code);
echo "Exit code: $code\n";
echo implode("\n", $out);
