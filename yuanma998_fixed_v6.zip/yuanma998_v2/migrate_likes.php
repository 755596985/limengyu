<?php
require __DIR__ . '/include/bootstrap.php';
header('Content-Type: text/html; charset=utf-8');

try {
    // Check if likes column exists (MySQL)
    $stmt = db()->query("SHOW COLUMNS FROM cp_comments LIKE 'likes'");
    $hasLikes = (bool)$stmt->fetch();
    if (!$hasLikes) {
        db()->exec("ALTER TABLE cp_comments ADD COLUMN likes INT DEFAULT 0");
        echo "<p>cp_comments.likes 列已添加</p>";
    } else {
        echo "<p>cp_comments.likes 列已存在，跳过</p>";
    }

    // Create cp_comment_likes table if not exists (MySQL)
    db()->exec("CREATE TABLE IF NOT EXISTS cp_comment_likes (
        comment_id VARCHAR(64) NOT NULL,
        user_id VARCHAR(64) NOT NULL,
        created_at DATETIME NOT NULL DEFAULT NOW(),
        PRIMARY KEY (comment_id, user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    echo "<p>cp_comment_likes 表已就绪</p>";

    // Add voice column if not exists
    $stmt = db()->query("SHOW COLUMNS FROM cp_comments LIKE 'voice'");
    $hasVoice = (bool)$stmt->fetch();
    if (!$hasVoice) {
        db()->exec("ALTER TABLE cp_comments ADD COLUMN voice VARCHAR(255) DEFAULT '' AFTER text");
        echo "<p>cp_comments.voice 列已添加（语音留言）</p>";
    } else {
        echo "<p>cp_comments.voice 列已存在，跳过</p>";
    }

    echo "<p style='color:green;font-weight:bold'>迁移完成！</p>";
} catch (Throwable $e) {
    echo "<p style='color:red'>错误: " . htmlspecialchars($e->getMessage()) . "</p>";
}
