<?php
return [
    'host'    => 'sql108.infinityfree.com',
    'port'    => 3306,
    'dbname'  => 'if0_42527328_yu',
    'user'    => 'if0_42527328',
    'pass'    => 'RJxwzFAVnZMrPr',
    'charset' => 'utf8mb4',
];
