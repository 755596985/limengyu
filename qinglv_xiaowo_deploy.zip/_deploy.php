<?php
/**
 * 情侣小窝 — 一键部署脚本
 * 上传后访问 http://你的域名/_deploy.php 即可完成初始化
 * 部署成功后会显示默认管理员账号密码，使用后请删除本文件
 */
header('Content-Type: text/html; charset=utf-8');
echo '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>安装</title>';
echo '<style>body{font-family:system-ui,sans-serif;max-width:600px;margin:50px auto;padding:20px;background:#f5f5f5}h2{color:#333}.ok{color:#27ae60}.err{color:#e74c3c}.box{background:#fff;padding:20px;border-radius:8px;margin:10px 0;box-shadow:0 1px 3px rgba(0,0,0,.1)}pre{background:#2d3436;color:#dfe6e9;padding:12px;border-radius:6px;overflow-x:auto}</style></head><body>';

// 1. Load DB config
$dbCfg = require __DIR__ . '/include/config.db.php';
echo '<div class="box"><strong>数据库配置</strong><br>Host: ' . htmlspecialchars($dbCfg['host']) . '<br>DB: ' . htmlspecialchars($dbCfg['dbname']) . '</div>';

// 2. Connect
try {
    $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=%s', $dbCfg['host'], $dbCfg['port'], $dbCfg['dbname'], $dbCfg['charset']);
    $pdo = new PDO($dsn, $dbCfg['user'], $dbCfg['pass'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    echo '<div class="box"><span class="ok">数据库连接成功</span></div>';
} catch (Throwable $e) {
    die('<div class="box"><span class="err">数据库连接失败: ' . htmlspecialchars($e->getMessage()) . '</span></div>');
}

// 3. Create tables
$tables = [
    "CREATE TABLE IF NOT EXISTS cp_config (
        id INT PRIMARY KEY DEFAULT 1,
        name1 VARCHAR(50) DEFAULT '男神',
        name2 VARCHAR(50) DEFAULT '女神',
        love_date DATE DEFAULT '2024-01-01',
        site_title VARCHAR(255) DEFAULT '',
        beian TEXT DEFAULT '',
        avatar1 VARCHAR(500) DEFAULT '',
        avatar2 VARCHAR(500) DEFAULT '',
        background_image VARCHAR(500) DEFAULT '',
        love_title VARCHAR(100) DEFAULT '已经在一起',
        show_comments TINYINT(1) DEFAULT 1,
        show_album TINYINT(1) DEFAULT 1,
        show_places TINYINT(1) DEFAULT 1,
        show_todos TINYINT(1) DEFAULT 1,
        show_user_posts TINYINT(1) DEFAULT 1
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    "CREATE TABLE IF NOT EXISTS cp_posts (
        id VARCHAR(32) PRIMARY KEY,
        title VARCHAR(255) DEFAULT '',
        tags TEXT,
        content TEXT,
        author VARCHAR(50) DEFAULT '1',
        mood VARCHAR(10) DEFAULT '💕',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        images TEXT,
        video VARCHAR(500) DEFAULT '',
        music VARCHAR(500) DEFAULT '',
        ip VARCHAR(45) DEFAULT '',
        location VARCHAR(200) DEFAULT '',
        user_id VARCHAR(32) DEFAULT NULL,
        user_nick VARCHAR(50) DEFAULT NULL,
        user_color VARCHAR(7) DEFAULT NULL,
        INDEX idx_user (user_id),
        INDEX idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    "CREATE TABLE IF NOT EXISTS cp_comments (
        id VARCHAR(32) PRIMARY KEY,
        post_id VARCHAR(32) NOT NULL,
        nick VARCHAR(100) DEFAULT '',
        text TEXT,
        voice VARCHAR(500) DEFAULT '',
        ip VARCHAR(45) DEFAULT '',
        user_id VARCHAR(32) DEFAULT NULL,
        parent_id VARCHAR(32) DEFAULT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        likes INT DEFAULT 0,
        INDEX idx_post (post_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    "CREATE TABLE IF NOT EXISTS cp_users (
        id VARCHAR(32) PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        nickname VARCHAR(100) DEFAULT '',
        avatar VARCHAR(500) DEFAULT '',
        avatar_color VARCHAR(7) DEFAULT '#d4786e',
        ip VARCHAR(45) DEFAULT '',
        location VARCHAR(200) DEFAULT '',
        email VARCHAR(200) DEFAULT '',
        status VARCHAR(20) DEFAULT 'active',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    "CREATE TABLE IF NOT EXISTS cp_photos (
        id VARCHAR(32) PRIMARY KEY,
        url VARCHAR(500) NOT NULL,
        title VARCHAR(255) DEFAULT '',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    "CREATE TABLE IF NOT EXISTS cp_places (
        id VARCHAR(32) PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        note TEXT,
        image VARCHAR(500) DEFAULT '',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    "CREATE TABLE IF NOT EXISTS cp_todos (
        id VARCHAR(32) PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        note TEXT,
        done TINYINT(1) DEFAULT 0,
        done_time VARCHAR(20) DEFAULT '',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    "CREATE TABLE IF NOT EXISTS cp_pages (
        id VARCHAR(32) PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        slug VARCHAR(100) NOT NULL,
        icon VARCHAR(10) DEFAULT '📄',
        content TEXT,
        sort INT DEFAULT 99,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    "CREATE TABLE IF NOT EXISTS cp_admin (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    "CREATE TABLE IF NOT EXISTS cp_visit (
        id INT PRIMARY KEY DEFAULT 1,
        total INT DEFAULT 0,
        today INT DEFAULT 0,
        visit_date DATE DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    "CREATE TABLE IF NOT EXISTS cp_about (
        id INT PRIMARY KEY DEFAULT 1,
        version VARCHAR(50) DEFAULT '',
        version_desc TEXT DEFAULT '',
        boy_name VARCHAR(50) DEFAULT '',
        boy_intro TEXT DEFAULT '',
        girl_name VARCHAR(50) DEFAULT '',
        girl_intro TEXT DEFAULT '',
        boy_avatar_url VARCHAR(500) DEFAULT '',
        girl_avatar_url VARCHAR(500) DEFAULT ''
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    "CREATE TABLE IF NOT EXISTS cp_comment_likes (
        comment_id VARCHAR(32) NOT NULL,
        user_id VARCHAR(32) NOT NULL,
        type VARCHAR(10) DEFAULT 'like',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (comment_id, user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
];

$created = 0;
foreach ($tables as $sql) {
    try {
        $pdo->exec($sql);
        $created++;
    } catch (Throwable $e) {
        echo '<div class="box"><span class="err">建表失败: ' . htmlspecialchars($e->getMessage()) . '</span><pre>' . htmlspecialchars(substr($sql, 0, 100)) . '...</pre></div>';
    }
}
echo '<div class="box"><span class="ok">数据表创建完成 (' . $created . '/' . count($tables) . ')</span></div>';

// 4. Insert default data
try {
    $pdo->exec("INSERT IGNORE INTO cp_config (id) VALUES (1)");
    $pdo->exec("INSERT IGNORE INTO cp_visit (id,total,today,visit_date) VALUES (1,0,0,CURDATE())");
    $pdo->exec("INSERT IGNORE INTO cp_about (id) VALUES (1)");

    // Admin: admin / 123456 (consistent with existing server state)
    $hash = password_hash('123456', PASSWORD_DEFAULT);
    $pdo->prepare("INSERT IGNORE INTO cp_admin (username,password) VALUES (?,?)")->execute(['admin', $hash]);

    echo '<div class="box"><span class="ok">默认数据写入完成</span></div>';
} catch (Throwable $e) {
    echo '<div class="box"><span class="err">写入默认数据失败: ' . htmlspecialchars($e->getMessage()) . '</span></div>';
}

// 5. Create data directory
$dataDir = __DIR__ . '/data';
if (!is_dir($dataDir)) {
    mkdir($dataDir, 0755, true);
}
// filter_words.php
$filterFile = $dataDir . '/filter_words.php';
if (!file_exists($filterFile)) {
    file_put_contents($filterFile, '<' . '?php exit;?>' . "\n" . '[]', LOCK_EX);
}
// visitors.php
$visitorFile = $dataDir . '/visitors.php';
if (!file_exists($visitorFile)) {
    file_put_contents($visitorFile, '<' . '?php exit;?>' . "\n" . '[]', LOCK_EX);
}
echo '<div class="box"><span class="ok">data 目录初始化完成</span></div>';

// 6. Create uploads directory
$uploadsDir = __DIR__ . '/uploads';
if (!is_dir($uploadsDir)) {
    mkdir($uploadsDir, 0755, true);
}
echo '<div class="box"><span class="ok">uploads 目录初始化完成</span></div>';

// 7. Summary
echo '<div class="box" style="background:#eafaf1;border:1px solid #27ae60">';
echo '<h2>部署成功!</h2>';
echo '<p><strong>后台地址:</strong> <a href="admin/index.php">admin/index.php</a></p>';
echo '<p><strong>管理员账号:</strong> admin</p>';
echo '<p><strong>管理员密码:</strong> 123456</p>';
echo '<p style="color:#e74c3c;">部署完成后请立即删除 <code>_deploy.php</code> !</p>';
echo '</div>';

echo '</body></html>';
