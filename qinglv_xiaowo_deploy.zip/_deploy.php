<?php
/**
 * 情侣小窝 — 一键部署
 * 上传后访问 _deploy.php 完成初始化，部署成功请删除本文件
 */
header('Content-Type: text/html; charset=utf-8');
echo '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>安装中...</title>';
echo '<style>body{font-family:system-ui,sans-serif;max-width:600px;margin:30px auto;padding:15px;background:#f5f5f5}h2{color:#333}.ok{color:#27ae60}.err{color:#e74c3c}.box{background:#fff;padding:16px;border-radius:8px;margin:8px 0;box-shadow:0 1px 3px rgba(0,0,0,.1)}pre{background:#2d3436;color:#dfe6e9;padding:10px;border-radius:6px;overflow-x:auto;font-size:13px}</style></head><body>';

// === 1. 加载数据库配置 ===
$dbCfg = require __DIR__ . '/include/config.db.php';
echo '<div class="box"><strong>数据库</strong><br>' . htmlspecialchars($dbCfg['host']) . ' / ' . htmlspecialchars($dbCfg['dbname']) . '</div>';

try {
    $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=%s', $dbCfg['host'], $dbCfg['port'], $dbCfg['dbname'], $dbCfg['charset']);
    $pdo = new PDO($dsn, $dbCfg['user'], $dbCfg['pass'], [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    echo '<div class="box"><span class="ok">数据库连接成功</span></div>';
} catch (Throwable $e) {
    die('<div class="box"><span class="err">连接失败: ' . htmlspecialchars($e->getMessage()) . '</span></div>');
}

// === 2. 建表 ===
$tables = [
    "CREATE TABLE IF NOT EXISTS cp_config (
        id INT PRIMARY KEY DEFAULT 1,
        name1 VARCHAR(50) DEFAULT '男神', name2 VARCHAR(50) DEFAULT '女神',
        love_date DATE DEFAULT '2024-01-01', site_title VARCHAR(255) DEFAULT '',
        beian TEXT DEFAULT '', avatar1 VARCHAR(500) DEFAULT '', avatar2 VARCHAR(500) DEFAULT '',
        background_image VARCHAR(500) DEFAULT '', love_title VARCHAR(100) DEFAULT '已经在一起',
        show_comments TINYINT(1) DEFAULT 1, show_album TINYINT(1) DEFAULT 1,
        show_places TINYINT(1) DEFAULT 1, show_todos TINYINT(1) DEFAULT 1,
        show_user_posts TINYINT(1) DEFAULT 1
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    "CREATE TABLE IF NOT EXISTS cp_posts (
        id VARCHAR(32) PRIMARY KEY, title VARCHAR(255) DEFAULT '', tags TEXT, content TEXT,
        author VARCHAR(50) DEFAULT '1', mood VARCHAR(10) DEFAULT '💕',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP, images TEXT,
        video VARCHAR(500) DEFAULT '', music VARCHAR(500) DEFAULT '',
        ip VARCHAR(45) DEFAULT '', location VARCHAR(200) DEFAULT '',
        user_id VARCHAR(32) DEFAULT NULL, user_nick VARCHAR(50) DEFAULT NULL,
        user_color VARCHAR(7) DEFAULT NULL,
        INDEX idx_user (user_id), INDEX idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    "CREATE TABLE IF NOT EXISTS cp_comments (
        id VARCHAR(32) PRIMARY KEY, post_id VARCHAR(32) NOT NULL,
        nick VARCHAR(100) DEFAULT '', text TEXT, voice VARCHAR(500) DEFAULT '',
        ip VARCHAR(45) DEFAULT '', user_id VARCHAR(32) DEFAULT NULL,
        parent_id VARCHAR(32) DEFAULT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        likes INT DEFAULT 0, INDEX idx_post (post_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    "CREATE TABLE IF NOT EXISTS cp_users (
        id VARCHAR(32) PRIMARY KEY, username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL, nickname VARCHAR(100) DEFAULT '',
        avatar VARCHAR(500) DEFAULT '', avatar_color VARCHAR(7) DEFAULT '#d4786e',
        ip VARCHAR(45) DEFAULT '', location VARCHAR(200) DEFAULT '',
        email VARCHAR(200) DEFAULT '', status VARCHAR(20) DEFAULT 'active',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    "CREATE TABLE IF NOT EXISTS cp_photos (
        id VARCHAR(32) PRIMARY KEY, url VARCHAR(500) NOT NULL,
        title VARCHAR(255) DEFAULT '', created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    "CREATE TABLE IF NOT EXISTS cp_places (
        id VARCHAR(32) PRIMARY KEY, name VARCHAR(255) NOT NULL,
        note TEXT, image VARCHAR(500) DEFAULT '', created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    "CREATE TABLE IF NOT EXISTS cp_todos (
        id VARCHAR(32) PRIMARY KEY, title VARCHAR(255) NOT NULL,
        note TEXT, done TINYINT(1) DEFAULT 0, done_time VARCHAR(20) DEFAULT '',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    "CREATE TABLE IF NOT EXISTS cp_pages (
        id VARCHAR(32) PRIMARY KEY, title VARCHAR(255) NOT NULL,
        slug VARCHAR(100) NOT NULL, icon VARCHAR(10) DEFAULT '📄',
        content TEXT, sort INT DEFAULT 99, created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    "CREATE TABLE IF NOT EXISTS cp_admin (
        id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    "CREATE TABLE IF NOT EXISTS cp_visit (
        id INT PRIMARY KEY DEFAULT 1, total INT DEFAULT 0,
        today INT DEFAULT 0, visit_date DATE DEFAULT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    "CREATE TABLE IF NOT EXISTS cp_about (
        id INT PRIMARY KEY DEFAULT 1, version VARCHAR(50) DEFAULT '',
        version_desc TEXT DEFAULT '', boy_name VARCHAR(50) DEFAULT '',
        boy_intro TEXT DEFAULT '', girl_name VARCHAR(50) DEFAULT '',
        girl_intro TEXT DEFAULT '', boy_avatar_url VARCHAR(500) DEFAULT '',
        girl_avatar_url VARCHAR(500) DEFAULT ''
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    "CREATE TABLE IF NOT EXISTS cp_comment_likes (
        comment_id VARCHAR(32) NOT NULL, user_id VARCHAR(32) NOT NULL,
        type VARCHAR(10) DEFAULT 'like', created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (comment_id, user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
];

$ok = 0;
foreach ($tables as $sql) {
    try { $pdo->exec($sql); $ok++; }
    catch (Throwable $e) { echo '<div class="box"><span class="err">建表失败: ' . htmlspecialchars($e->getMessage()) . '</span></div>'; }
}
echo '<div class="box"><span class="ok">数据表 ' . $ok . '/' . count($tables) . ' 创建完成</span></div>';

// === 3. 默认数据 ===
try {
    $pdo->exec("INSERT IGNORE INTO cp_config (id) VALUES (1)");
    $pdo->exec("INSERT IGNORE INTO cp_visit (id,total,today,visit_date) VALUES (1,0,0,CURDATE())");
    $pdo->exec("INSERT IGNORE INTO cp_about (id) VALUES (1)");

    $hash = password_hash('123456', PASSWORD_DEFAULT);
    $pdo->prepare("INSERT IGNORE INTO cp_admin (username,password) VALUES (?,?)")->execute(['admin', $hash]);

    echo '<div class="box"><span class="ok">默认数据写入完成</span></div>';
} catch (Throwable $e) {
    echo '<div class="box"><span class="err">默认数据失败: ' . htmlspecialchars($e->getMessage()) . '</span></div>';
}

// === 4. 初始化 data 目录 ===
$dataDir = __DIR__ . '/data';
if (!is_dir($dataDir)) mkdir($dataDir, 0755, true);

$files = [
    'filter_words.php' => '<' . '?php exit;?>' . "\n" . json_encode(["草你"], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
    'visitors.php' => '<' . '?php exit;?>' . "\n" . '[]',
    'yiyan.php' => '<' . '?php exit;?>' . "\n" . json_encode([
        ["id"=>1,"text"=>"你是我这一生等了半世未拆的礼物","author"=>"林夕","source"=>""],
        ["id"=>2,"text"=>"世间万物皆苦，你明目张胆的偏爱就是救赎","author"=>"佚名","source"=>""],
        ["id"=>3,"text"=>"见到你，我觉得多少适应了这个世界","author"=>"村上春树","source"=>"《挪威的森林》"],
        ["id"=>4,"text"=>"你是年少的欢喜，这句话反过来也是你","author"=>"佚名","source"=>""],
        ["id"=>5,"text"=>"我想和你互相浪费，一起虚度短的沉默，长的无意义","author"=>"李元胜","source"=>"《我想和你虚度时光》"],
        ["id"=>6,"text"=>"答案很长，我准备用一生的时间来回答，你准备要听了吗","author"=>"林徽因","source"=>""],
        ["id"=>7,"text"=>"要是世上只有我们两个人多么好，我一定要把你欺负得哭不出来","author"=>"朱生豪","source"=>"《朱生豪情书》"],
        ["id"=>8,"text"=>"第一次见到你的时候，我的心炸成了烟花，需要用一生来打扫灰炉","author"=>"钱锛书","source"=>""],
        ["id"=>9,"text"=>"我这一生都是坚定不移的唯物主义者，唯有你，我希望有来生","author"=>"周恩来","source"=>"致邓颖超"],
        ["id"=>10,"text"=>"你来人间一趟，你要看看太阳，和你的心上人，一起走在街上","author"=>"海子","source"=>"《夏天的太阳》"],
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT),
    'yiyan_config.json' => json_encode(["last_id"=>10], JSON_UNESCAPED_UNICODE),
    'posts.php' => '<' . '?php exit;?>' . "\n" . '[]',
    'comments.php' => '<' . '?php exit;?>' . "\n" . '[]',
    'photos.php' => '<' . '?php exit;?>' . "\n" . '[]',
    'places.php' => '<' . '?php exit;?>' . "\n" . '[]',
    'todos.php' => '<' . '?php exit;?>' . "\n" . '[]',
    'pages.php' => '<' . '?php exit;?>' . "\n" . '[]',
    'users.php' => '<' . '?php exit;?>' . "\n" . '[]',
    'config.php' => '<' . '?php exit;?>' . "\n" . '[]',
    'about.php' => '<' . '?php exit;?>' . "\n" . '[]',
    'visit.php' => '<' . '?php exit;?>' . "\n" . '[]',
    'admin_pass.php' => '<' . '?php exit;?>' . "\n" . '[]',
];

foreach ($files as $name => $content) {
    file_put_contents($dataDir . '/' . $name, $content, LOCK_EX);
}
echo '<div class="box"><span class="ok">data 目录 (' . count($files) . ' 个文件) 初始化完成</span></div>';

// === 5. uploads 目录 ===
$uploadsDir = __DIR__ . '/uploads';
if (!is_dir($uploadsDir)) mkdir($uploadsDir, 0755, true);
echo '<div class="box"><span class="ok">uploads 目录初始化完成</span></div>';

// === 完成 ===
echo '<div class="box" style="background:#eafaf1;border:1px solid #27ae60">';
echo '<h2>部署成功</h2>';
echo '<p><strong>后台:</strong> <a href="admin/index.php">admin/index.php</a></p>';
echo '<p><strong>账号:</strong> admin</p>';
echo '<p><strong>密码:</strong> 123456</p>';
echo '<p style="color:#e74c3c;">请立即删除 <code>_deploy.php</code></p>';
echo '</div></body></html>';
