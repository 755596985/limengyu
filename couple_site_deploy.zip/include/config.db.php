<?php
/**
 * 数据库配置 — 部署时修改为你自己的数据库信息。
 * 也可通过环境变量设置: CP_DB_HOST / CP_DB_PORT / CP_DB_NAME / CP_DB_USER / CP_DB_PASS
 */
return [
    'host'    => getenv('CP_DB_HOST') ?: 'localhost',
    'port'    => (int)(getenv('CP_DB_PORT') ?: 3306),
    'dbname'  => getenv('CP_DB_NAME') ?: 'your_database',
    'user'    => getenv('CP_DB_USER') ?: 'your_user',
    'pass'    => getenv('CP_DB_PASS') ?: 'your_password',
    'charset' => 'utf8mb4',
];
