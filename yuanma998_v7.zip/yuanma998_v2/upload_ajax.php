<?php
/**
 * AJAX 图片上传端点
 * 前端选图后即时上传，返回 JSON
 */
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'error' => 'Method not allowed'], JSON_UNESCAPED_UNICODE);
    exit;
}

$ROOT = dirname(__FILE__);
$UPLOAD_DIR = $ROOT . '/uploads/';
if (!is_dir($UPLOAD_DIR)) mkdir($UPLOAD_DIR, 0755, true);

$IMG_EXT = ['jpg','jpeg','png','gif','webp'];
$IMG_MIME = ['image/jpeg','image/png','image/gif','image/webp'];

if (empty($_FILES['file']['tmp_name']) || ($_FILES['file']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
    echo json_encode(['success' => false, 'error' => '未选择文件'], JSON_UNESCAPED_UNICODE);
    exit;
}

$tmp  = $_FILES['file']['tmp_name'];
$size = $_FILES['file']['size'] ?? 0;

if ($size > 8 * 1024 * 1024) {
    echo json_encode(['success' => false, 'error' => '文件太大，最大 8MB'], JSON_UNESCAPED_UNICODE);
    exit;
}

$ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
if (!in_array($ext, $IMG_EXT, true)) {
    echo json_encode(['success' => false, 'error' => '不支持的文件格式'], JSON_UNESCAPED_UNICODE);
    exit;
}

if (class_exists('finfo')) {
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($tmp) ?: '';
    if ($mime && !in_array($mime, $IMG_MIME, true)) {
        echo json_encode(['success' => false, 'error' => '不支持的文件类型'], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

$fn = time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
if (move_uploaded_file($tmp, $UPLOAD_DIR . $fn)) {
    echo json_encode(['success' => true, 'url' => 'uploads/' . $fn], JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode(['success' => false, 'error' => '上传失败，请重试'], JSON_UNESCAPED_UNICODE);
}
